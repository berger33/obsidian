# Recorte materializado do checkpoint

Pacote: `vibe-coding-riscos`
Notas: 200
Filtro: domain=vibe-coding, subdomain=riscos
