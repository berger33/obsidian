# Recorte materializado do checkpoint

Pacote: `vibe-coding-spec-driven-dev`
Notas: 200
Filtro: domain=vibe-coding, subdomain=spec-driven-dev
