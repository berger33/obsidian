# Recorte materializado do checkpoint

Pacote: `ia-multimodal`
Notas: 200
Filtro: domain=ia, subdomain=multimodal
