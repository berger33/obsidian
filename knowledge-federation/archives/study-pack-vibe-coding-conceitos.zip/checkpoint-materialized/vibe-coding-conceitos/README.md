# Recorte materializado do checkpoint

Pacote: `vibe-coding-conceitos`
Notas: 200
Filtro: domain=vibe-coding, subdomain=conceitos
