# Recorte materializado do checkpoint

Pacote: `vibe-coding-estudos`
Notas: 200
Filtro: domain=vibe-coding, subdomain=estudos
