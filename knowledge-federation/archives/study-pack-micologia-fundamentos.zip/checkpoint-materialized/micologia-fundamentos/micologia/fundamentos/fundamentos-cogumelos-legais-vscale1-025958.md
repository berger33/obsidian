---
id: virtual.vscale1.micologia.fundamentos.000025958
tipo: conceito
dominio: micologia
subdominio: fundamentos
nivel: iniciante
confianca: media
ultima_verificacao: 2026-09-30
validade: volatil
risco_legal: alto
risco_medico: alto
conteudo_operacional: false
status: materializada-do-checkpoint
fontes: []
tags: [dominio/micologia, subdominio/fundamentos, origem/checkpoint]
aliases: ["Fundamentos - Cogumelos Legais — vscale1 #025958"]
prefixo_virtual: vscale1
---
# Fundamentos - Cogumelos Legais — vscale1 #025958

> [!warning] Domínio regulado
> Conteúdo educacional para organização de estudo e conversa com profissionais habilitados. Não é prescrição, parecer jurídico nem instrução operacional.

## Em uma frase
Nota virtual sobre Fundamentos - Cogumelos Legais — vscale1 #025958, para estudo incremental em micologia/fundamentos.

## Por que importa
Esta nota é um recorte materializado do ledger de 1 milhão de notas. Ela deve ser usada como ponto de partida para estudo, pesquisa e refinamento com fontes primárias.

## Como funciona
Esta nota foi criada como registro virtual ledger-first. Ao materializar, expanda com fontes primárias, conexões e perguntas de verificação. Foco: literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas.

## Como pedir isso para uma IA
```text
Expanda a nota "Fundamentos - Cogumelos Legais — vscale1 #025958" com fontes primárias, exemplos seguros, conexões e critérios de verificação. Separe fato, hipótese, opinião e marketing.
```

## Como verificar
- Conferir documentação, literatura ou fonte regulatória primária.
- Registrar data de verificação.
- Em software, validar com execução, teste e revisão de diff.
- Em saúde, direito ou domínios regulados, transformar em perguntas para profissional habilitado.

## Conexões
- [[fundamentos-cogumelos-legais-vscale1-026348]] — relacionada no mesmo recorte materializado.
- [[fundamentos-cogumelos-legais-vscale1-026738]] — relacionada no mesmo recorte materializado.
- [[fundamentos-cogumelos-legais-vscale1-027128]] — relacionada no mesmo recorte materializado.
- [[fundamentos-cogumelos-legais-vscale1-027518]] — relacionada no mesmo recorte materializado.
- [[fundamentos-cogumelos-legais-vscale1-027908]] — relacionada no mesmo recorte materializado.

## Fontes a buscar
- literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas
