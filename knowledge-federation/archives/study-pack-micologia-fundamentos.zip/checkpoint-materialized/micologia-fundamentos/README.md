# Recorte materializado do checkpoint

Pacote: `micologia-fundamentos`
Notas: 200
Filtro: domain=micologia, subdomain=fundamentos
