# Recorte materializado do checkpoint

Pacote: `ia-fundamentos`
Notas: 200
Filtro: domain=ia, subdomain=fundamentos
