# Recorte materializado do checkpoint

Pacote: `jogos-audio`
Notas: 200
Filtro: domain=jogos, subdomain=audio
