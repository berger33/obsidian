# Recorte materializado do checkpoint

Pacote: `micologia-psilocibina-pesquisa-clinica`
Notas: 200
Filtro: domain=micologia, subdomain=psilocibina-pesquisa-clinica
