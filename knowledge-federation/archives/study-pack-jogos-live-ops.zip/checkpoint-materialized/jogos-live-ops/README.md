# Recorte materializado do checkpoint

Pacote: `jogos-live-ops`
Notas: 200
Filtro: domain=jogos, subdomain=live-ops
