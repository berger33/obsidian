# Recorte materializado do checkpoint

Pacote: `negocio-distribuicao`
Notas: 200
Filtro: domain=negocio-carreira-produto, subdomain=distribuicao
