# Recorte materializado do checkpoint

Pacote: `cannabis-legal-regulatorio`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=legal-regulatorio
