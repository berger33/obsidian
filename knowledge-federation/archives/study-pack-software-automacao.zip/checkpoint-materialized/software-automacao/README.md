# Recorte materializado do checkpoint

Pacote: `software-automacao`
Notas: 200
Filtro: domain=software, subdomain=automacao
