# Recorte materializado do checkpoint

Pacote: `vibe-coding-ferramentas`
Notas: 200
Filtro: domain=vibe-coding, subdomain=ferramentas
