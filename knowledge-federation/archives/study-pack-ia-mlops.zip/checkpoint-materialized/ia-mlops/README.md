# Recorte materializado do checkpoint

Pacote: `ia-mlops`
Notas: 200
Filtro: domain=ia, subdomain=mlops
