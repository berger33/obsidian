# Recorte materializado do checkpoint

Pacote: `software-low-code`
Notas: 200
Filtro: domain=software, subdomain=low-code
