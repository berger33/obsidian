# Recorte materializado do checkpoint

Pacote: `cannabis-terpenos`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=terpenos
