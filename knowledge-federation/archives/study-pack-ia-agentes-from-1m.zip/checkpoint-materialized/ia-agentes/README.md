# Recorte materializado do checkpoint

Pacote: `ia-agentes`
Notas: 200
Filtro: domain=ia, subdomain=agentes
