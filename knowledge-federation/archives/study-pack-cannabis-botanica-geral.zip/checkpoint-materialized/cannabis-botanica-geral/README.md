# Recorte materializado do checkpoint

Pacote: `cannabis-botanica-geral`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=botanica-geral
