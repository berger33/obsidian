# Recorte materializado do checkpoint

Pacote: `cannabis-canabinoides`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=canabinoides
