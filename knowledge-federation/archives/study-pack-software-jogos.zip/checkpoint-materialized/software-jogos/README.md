# Recorte materializado do checkpoint

Pacote: `software-jogos`
Notas: 200
Filtro: domain=software, subdomain=jogos
