# Recorte materializado do checkpoint

Pacote: `software-desktop`
Notas: 200
Filtro: domain=software, subdomain=desktop
