# Recorte materializado do checkpoint

Pacote: `ia-llms`
Notas: 200
Filtro: domain=ia, subdomain=llms
