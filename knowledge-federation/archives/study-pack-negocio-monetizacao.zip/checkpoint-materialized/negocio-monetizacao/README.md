# Recorte materializado do checkpoint

Pacote: `negocio-monetizacao`
Notas: 200
Filtro: domain=negocio-carreira-produto, subdomain=monetizacao
