# Recorte materializado do checkpoint

Pacote: `software-mobile`
Notas: 200
Filtro: domain=software, subdomain=mobile
