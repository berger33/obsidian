# Recorte materializado do checkpoint

Pacote: `micologia-cogumelos-comestiveis-legais`
Notas: 200
Filtro: domain=micologia, subdomain=cogumelos-comestiveis-legais
