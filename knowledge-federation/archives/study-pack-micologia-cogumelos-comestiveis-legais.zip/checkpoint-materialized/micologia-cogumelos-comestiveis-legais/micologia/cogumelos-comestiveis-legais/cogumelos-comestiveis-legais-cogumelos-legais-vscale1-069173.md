---
id: virtual.vscale1.micologia.cogumelos-comestiveis-legais.000069173
tipo: conceito
dominio: micologia
subdominio: cogumelos-comestiveis-legais
nivel: iniciante
confianca: media
ultima_verificacao: 2026-09-30
validade: volatil
risco_legal: alto
risco_medico: alto
conteudo_operacional: false
status: materializada-do-checkpoint
fontes: []
tags: [dominio/micologia, subdominio/cogumelos-comestiveis-legais, origem/checkpoint]
aliases: ["Cogumelos Comestiveis Legais - Cogumelos Legais — vscale1 #069173"]
prefixo_virtual: vscale1
---
# Cogumelos Comestiveis Legais - Cogumelos Legais — vscale1 #069173

> [!warning] Domínio regulado
> Conteúdo educacional para organização de estudo e conversa com profissionais habilitados. Não é prescrição, parecer jurídico nem instrução operacional.

## Em uma frase
Nota virtual sobre Cogumelos Comestiveis Legais - Cogumelos Legais — vscale1 #069173, para estudo incremental em micologia/cogumelos-comestiveis-legais.

## Por que importa
Esta nota é um recorte materializado do ledger de 1 milhão de notas. Ela deve ser usada como ponto de partida para estudo, pesquisa e refinamento com fontes primárias.

## Como funciona
Esta nota foi criada como registro virtual ledger-first. Ao materializar, expanda com fontes primárias, conexões e perguntas de verificação. Foco: literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas.

## Como pedir isso para uma IA
```text
Expanda a nota "Cogumelos Comestiveis Legais - Cogumelos Legais — vscale1 #069173" com fontes primárias, exemplos seguros, conexões e critérios de verificação. Separe fato, hipótese, opinião e marketing.
```

## Como verificar
- Conferir documentação, literatura ou fonte regulatória primária.
- Registrar data de verificação.
- Em software, validar com execução, teste e revisão de diff.
- Em saúde, direito ou domínios regulados, transformar em perguntas para profissional habilitado.

## Conexões
- [[cogumelos-comestiveis-legais-cogumelos-legais-vscale1-069563]] — relacionada no mesmo recorte materializado.
- [[cogumelos-comestiveis-legais-cogumelos-legais-vscale1-069953]] — relacionada no mesmo recorte materializado.
- [[cogumelos-comestiveis-legais-cogumelos-legais-vscale1-070343]] — relacionada no mesmo recorte materializado.
- [[cogumelos-comestiveis-legais-cogumelos-legais-vscale1-070733]] — relacionada no mesmo recorte materializado.
- [[cogumelos-comestiveis-legais-cogumelos-legais-vscale1-071123]] — relacionada no mesmo recorte materializado.

## Fontes a buscar
- literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas
