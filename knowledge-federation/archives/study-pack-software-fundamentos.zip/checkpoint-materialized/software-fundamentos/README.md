# Recorte materializado do checkpoint

Pacote: `software-fundamentos`
Notas: 200
Filtro: domain=software, subdomain=fundamentos
