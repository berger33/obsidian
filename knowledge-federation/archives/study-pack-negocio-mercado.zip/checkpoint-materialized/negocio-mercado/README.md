# Recorte materializado do checkpoint

Pacote: `negocio-mercado`
Notas: 200
Filtro: domain=negocio-carreira-produto, subdomain=mercado
