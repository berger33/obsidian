# Recorte materializado do checkpoint

Pacote: `software-produto`
Notas: 200
Filtro: domain=software, subdomain=produto
