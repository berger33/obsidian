# Recorte materializado do checkpoint

Pacote: `jogos-arte`
Notas: 200
Filtro: domain=jogos, subdomain=arte
