# Recorte materializado do checkpoint

Pacote: `negocio-produto`
Notas: 200
Filtro: domain=negocio-carreira-produto, subdomain=produto
