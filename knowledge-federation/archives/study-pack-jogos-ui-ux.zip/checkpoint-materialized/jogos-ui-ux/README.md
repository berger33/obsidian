# Recorte materializado do checkpoint

Pacote: `jogos-ui-ux`
Notas: 200
Filtro: domain=jogos, subdomain=ui-ux
