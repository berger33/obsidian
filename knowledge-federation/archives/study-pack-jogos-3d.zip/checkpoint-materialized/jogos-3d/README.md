# Recorte materializado do checkpoint

Pacote: `jogos-3d`
Notas: 200
Filtro: domain=jogos, subdomain=3d
