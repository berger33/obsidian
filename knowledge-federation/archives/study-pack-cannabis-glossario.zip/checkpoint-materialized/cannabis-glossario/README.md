# Recorte materializado do checkpoint

Pacote: `cannabis-glossario`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=glossario
