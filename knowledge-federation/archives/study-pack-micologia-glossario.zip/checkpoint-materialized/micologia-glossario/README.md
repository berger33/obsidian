# Recorte materializado do checkpoint

Pacote: `micologia-glossario`
Notas: 200
Filtro: domain=micologia, subdomain=glossario
