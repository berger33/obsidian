---
id: virtual.vscale1.micologia.psilocybe-historia-taxonomia-legislacao.000071203
tipo: conceito
dominio: micologia
subdominio: psilocybe-historia-taxonomia-legislacao
nivel: iniciante
confianca: media
ultima_verificacao: 2026-09-30
validade: volatil
risco_legal: alto
risco_medico: alto
conteudo_operacional: false
status: materializada-do-checkpoint
fontes: []
tags: [dominio/micologia, subdominio/psilocybe-historia-taxonomia-legislacao, origem/checkpoint]
aliases: ["Psilocybe Historia Taxonomia Legislacao - Cogumelos Legais — vscale1 #071203"]
prefixo_virtual: vscale1
---
# Psilocybe Historia Taxonomia Legislacao - Cogumelos Legais — vscale1 #071203

> [!warning] Domínio regulado
> Conteúdo educacional para organização de estudo e conversa com profissionais habilitados. Não é prescrição, parecer jurídico nem instrução operacional.

## Em uma frase
Nota virtual sobre Psilocybe Historia Taxonomia Legislacao - Cogumelos Legais — vscale1 #071203, para estudo incremental em micologia/psilocybe-historia-taxonomia-legislacao.

## Por que importa
Esta nota é um recorte materializado do ledger de 1 milhão de notas. Ela deve ser usada como ponto de partida para estudo, pesquisa e refinamento com fontes primárias.

## Como funciona
Esta nota foi criada como registro virtual ledger-first. Ao materializar, expanda com fontes primárias, conexões e perguntas de verificação. Foco: literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas.

## Como pedir isso para uma IA
```text
Expanda a nota "Psilocybe Historia Taxonomia Legislacao - Cogumelos Legais — vscale1 #071203" com fontes primárias, exemplos seguros, conexões e critérios de verificação. Separe fato, hipótese, opinião e marketing.
```

## Como verificar
- Conferir documentação, literatura ou fonte regulatória primária.
- Registrar data de verificação.
- Em software, validar com execução, teste e revisão de diff.
- Em saúde, direito ou domínios regulados, transformar em perguntas para profissional habilitado.

## Conexões
- [[psilocybe-historia-taxonomia-legislacao-cogumelos-legais-vscale1-071593]] — relacionada no mesmo recorte materializado.
- [[psilocybe-historia-taxonomia-legislacao-cogumelos-legais-vscale1-071983]] — relacionada no mesmo recorte materializado.
- [[psilocybe-historia-taxonomia-legislacao-cogumelos-legais-vscale1-072373]] — relacionada no mesmo recorte materializado.
- [[psilocybe-historia-taxonomia-legislacao-cogumelos-legais-vscale1-072763]] — relacionada no mesmo recorte materializado.
- [[psilocybe-historia-taxonomia-legislacao-cogumelos-legais-vscale1-073153]] — relacionada no mesmo recorte materializado.

## Fontes a buscar
- literatura científica, taxonomia, legislação e segurança; sem cultivo de espécies controladas
