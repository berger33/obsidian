# Recorte materializado do checkpoint

Pacote: `micologia-psilocybe-historia-taxonomia-legislacao`
Notas: 200
Filtro: domain=micologia, subdomain=psilocybe-historia-taxonomia-legislacao
