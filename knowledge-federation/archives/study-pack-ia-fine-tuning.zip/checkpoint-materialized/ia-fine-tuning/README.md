# Recorte materializado do checkpoint

Pacote: `ia-fine-tuning`
Notas: 200
Filtro: domain=ia, subdomain=fine-tuning
