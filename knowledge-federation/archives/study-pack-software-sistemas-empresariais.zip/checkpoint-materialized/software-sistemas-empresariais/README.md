# Recorte materializado do checkpoint

Pacote: `software-sistemas-empresariais`
Notas: 200
Filtro: domain=software, subdomain=sistemas-empresariais
