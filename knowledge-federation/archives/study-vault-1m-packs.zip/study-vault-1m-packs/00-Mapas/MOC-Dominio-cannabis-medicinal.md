---
tipo: moc-dominio
dominio: cannabis-medicinal
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Cannabis Medicinal (Educacional e Regulatório)"]
---
# Cannabis Medicinal (Educacional e Regulatório) — Mapa de Subdomínios

Domínio: `cannabis-medicinal`
Subdomínios / Study Packs: **11**
Notas curadas neste domínio: **2200**

## Study Packs do Domínio

- [[MOC-cannabis-legal-regulatorio]] — Cannabis Medicinal — Legal e Regulatório (200 notas) — `study-pack-cannabis-legal-regulatorio.zip`
- [[MOC-cannabis-documentacao-paciente]] — Cannabis Medicinal — Documentação do Paciente (200 notas) — `study-pack-cannabis-documentacao-paciente.zip`
- [[MOC-cannabis-botanica-geral]] — Cannabis Medicinal — Botânica Geral (200 notas) — `study-pack-cannabis-botanica-geral.zip`
- [[MOC-cannabis-farmacologia]] — Cannabis Medicinal — Farmacologia (200 notas) — `study-pack-cannabis-farmacologia.zip`
- [[MOC-cannabis-canabinoides]] — Cannabis Medicinal — Canabinoides (200 notas) — `study-pack-cannabis-canabinoides.zip`
- [[MOC-cannabis-terpenos]] — Cannabis Medicinal — Terpenos (200 notas) — `study-pack-cannabis-terpenos.zip`
- [[MOC-cannabis-formas-de-uso-legais]] — Cannabis Medicinal — Formas de Uso Legais (200 notas) — `study-pack-cannabis-formas-de-uso-legais.zip`
- [[MOC-cannabis-riscos-interacoes]] — Cannabis Medicinal — Riscos e Interações (200 notas) — `study-pack-cannabis-riscos-interacoes.zip`
- [[MOC-cannabis-estudos-clinicos]] — Cannabis Medicinal — Estudos Clínicos (200 notas) — `study-pack-cannabis-estudos-clinicos.zip`
- [[MOC-cannabis-qualidade-rastreabilidade]] — Cannabis Medicinal — Qualidade e Rastreabilidade (200 notas) — `study-pack-cannabis-qualidade-rastreabilidade.zip`
- [[MOC-cannabis-glossario]] — Cannabis Medicinal — Glossário (200 notas) — `study-pack-cannabis-glossario.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-cannabis-medicinal.canvas`
