---
tipo: moc-dominio
dominio: vibe-coding
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Vibe Coding e Orquestração Agêntica"]
---
# Vibe Coding e Orquestração Agêntica — Mapa de Subdomínios

Domínio: `vibe-coding`
Subdomínios / Study Packs: **10**
Notas curadas neste domínio: **2000**

## Study Packs do Domínio

- [[MOC-vibe-coding-conceitos]] — Vibe Coding — Conceitos (200 notas) — `study-pack-vibe-coding-conceitos.zip`
- [[MOC-vibe-coding-ferramentas]] — Vibe Coding — Ferramentas (200 notas) — `study-pack-vibe-coding-ferramentas.zip`
- [[MOC-vibe-coding-workflows]] — Vibe Coding — Workflows (200 notas) — `study-pack-vibe-coding-workflows.zip`
- [[MOC-vibe-coding-prompts]] — Vibe Coding — Prompts (200 notas) — `study-pack-vibe-coding-prompts.zip`
- [[MOC-vibe-coding-context-engineering]] — Vibe Coding — Context Engineering (200 notas) — `study-pack-vibe-coding-context-engineering.zip`
- [[MOC-vibe-coding-spec-driven-dev]] — Vibe Coding — Spec-Driven Dev (200 notas) — `study-pack-vibe-coding-spec-driven-dev.zip`
- [[MOC-vibe-coding-qualidade]] — Vibe Coding — Qualidade (200 notas) — `study-pack-vibe-coding-qualidade.zip`
- [[MOC-vibe-coding-riscos]] — Vibe Coding — Riscos (200 notas) — `study-pack-vibe-coding-riscos.zip`
- [[MOC-vibe-coding-estudos]] — Vibe Coding — Estudos (200 notas) — `study-pack-vibe-coding-estudos.zip`
- [[MOC-vibe-coding-orquestracao]] — Vibe Coding — Orquestração (200 notas) — `study-pack-vibe-coding-orquestracao.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-vibe-coding.canvas`
