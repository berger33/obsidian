---
tipo: moc-dominio
dominio: micologia
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Micologia Segura e Científica"]
---
# Micologia Segura e Científica — Mapa de Subdomínios

Domínio: `micologia`
Subdomínios / Study Packs: **9**
Notas curadas neste domínio: **1800**

## Study Packs do Domínio

- [[MOC-micologia-fundamentos]] — Micologia — Fundamentos (200 notas) — `study-pack-micologia-fundamentos.zip`
- [[MOC-micologia-taxonomia]] — Micologia — Taxonomia (200 notas) — `study-pack-micologia-taxonomia.zip`
- [[MOC-micologia-ecologia]] — Micologia — Ecologia (200 notas) — `study-pack-micologia-ecologia.zip`
- [[MOC-micologia-cogumelos-comestiveis-legais]] — Micologia — Cogumelos Comestíveis Legais (200 notas) — `study-pack-micologia-cogumelos-comestiveis-legais.zip`
- [[MOC-micologia-cogumelos-medicinais-legais]] — Micologia — Cogumelos Medicinais Legais (200 notas) — `study-pack-micologia-cogumelos-medicinais-legais.zip`
- [[MOC-micologia-psilocybe-historia-taxonomia-legislacao]] — Micologia — Psilocybe: História, Taxonomia e Legislação (200 notas) — `study-pack-micologia-psilocybe-historia-taxonomia-legislacao.zip`
- [[MOC-micologia-psilocibina-pesquisa-clinica]] — Micologia — Psilocibina: Pesquisa Clínica (200 notas) — `study-pack-micologia-psilocibina-pesquisa-clinica.zip`
- [[MOC-micologia-riscos-reducao-danos]] — Micologia — Riscos e Redução de Danos (200 notas) — `study-pack-micologia-riscos-reducao-danos.zip`
- [[MOC-micologia-glossario]] — Micologia — Glossário (200 notas) — `study-pack-micologia-glossario.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-micologia.canvas`
