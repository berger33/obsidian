---
tipo: moc-dominio
dominio: ia
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Inteligência Artificial"]
---
# Inteligência Artificial — Mapa de Subdomínios

Domínio: `ia`
Subdomínios / Study Packs: **12**
Notas curadas neste domínio: **2400**

## Study Packs do Domínio

- [[MOC-ia-fundamentos]] — IA — Fundamentos (200 notas) — `study-pack-ia-fundamentos.zip`
- [[MOC-ia-llms]] — IA — LLMs (200 notas) — `study-pack-ia-llms.zip`
- [[MOC-ia-agentes]] — IA — Agentes (200 notas) — `study-pack-ia-agentes-from-1m.zip`
- [[MOC-ia-rag]] — IA — RAG (200 notas) — `study-pack-ia-rag.zip`
- [[MOC-ia-fine-tuning]] — IA — Fine-Tuning (200 notas) — `study-pack-ia-fine-tuning.zip`
- [[MOC-ia-modelos-locais]] — IA — Modelos Locais (200 notas) — `study-pack-ia-modelos-locais.zip`
- [[MOC-ia-avaliacao]] — IA — Avaliação (200 notas) — `study-pack-ia-avaliacao.zip`
- [[MOC-ia-seguranca]] — IA — Segurança (200 notas) — `study-pack-ia-seguranca.zip`
- [[MOC-ia-custos]] — IA — Custos (200 notas) — `study-pack-ia-custos.zip`
- [[MOC-ia-ferramentas]] — IA — Ferramentas (200 notas) — `study-pack-ia-ferramentas.zip`
- [[MOC-ia-multimodal]] — IA — Multimodal (200 notas) — `study-pack-ia-multimodal.zip`
- [[MOC-ia-mlops]] — IA — MLOps (200 notas) — `study-pack-ia-mlops.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-ia.canvas`
