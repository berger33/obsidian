---
tipo: moc-dominio
dominio: jogos
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Desenvolvimento de Jogos"]
---
# Desenvolvimento de Jogos — Mapa de Subdomínios

Domínio: `jogos`
Subdomínios / Study Packs: **12**
Notas curadas neste domínio: **2400**

## Study Packs do Domínio

- [[MOC-jogos-2d]] — Jogos — 2D (200 notas) — `study-pack-jogos-2d.zip`
- [[MOC-jogos-3d]] — Jogos — 3D (200 notas) — `study-pack-jogos-3d.zip`
- [[MOC-jogos-engines]] — Jogos — Engines (200 notas) — `study-pack-jogos-engines.zip`
- [[MOC-jogos-netcode]] — Jogos — Netcode (200 notas) — `study-pack-jogos-netcode.zip`
- [[MOC-jogos-mmo]] — Jogos — MMO (200 notas) — `study-pack-jogos-mmo.zip`
- [[MOC-jogos-game-design]] — Jogos — Game Design (200 notas) — `study-pack-jogos-game-design.zip`
- [[MOC-jogos-level-design]] — Jogos — Level Design (200 notas) — `study-pack-jogos-level-design.zip`
- [[MOC-jogos-arte]] — Jogos — Arte (200 notas) — `study-pack-jogos-arte.zip`
- [[MOC-jogos-audio]] — Jogos — Áudio (200 notas) — `study-pack-jogos-audio.zip`
- [[MOC-jogos-ui-ux]] — Jogos — UI/UX (200 notas) — `study-pack-jogos-ui-ux.zip`
- [[MOC-jogos-publicacao]] — Jogos — Publicação (200 notas) — `study-pack-jogos-publicacao.zip`
- [[MOC-jogos-live-ops]] — Jogos — Live Ops (200 notas) — `study-pack-jogos-live-ops.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-jogos.canvas`
