---
tipo: moc-dominio
dominio: software
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Engenharia de Software"]
---
# Engenharia de Software — Mapa de Subdomínios

Domínio: `software`
Subdomínios / Study Packs: **16**
Notas curadas neste domínio: **3200**

## Study Packs do Domínio

- [[MOC-software-fundamentos]] — Software — Fundamentos (200 notas) — `study-pack-software-fundamentos.zip`
- [[MOC-software-arquitetura]] — Software — Arquitetura (200 notas) — `study-pack-software-arquitetura.zip`
- [[MOC-software-frontend]] — Software — Frontend (200 notas) — `study-pack-software-frontend.zip`
- [[MOC-software-backend]] — Software — Backend (200 notas) — `study-pack-software-backend.zip`
- [[MOC-software-mobile]] — Software — Mobile (200 notas) — `study-pack-software-mobile.zip`
- [[MOC-software-desktop]] — Software — Desktop (200 notas) — `study-pack-software-desktop.zip`
- [[MOC-software-dados]] — Software — Dados (200 notas) — `study-pack-software-dados.zip`
- [[MOC-software-devops]] — Software — DevOps (200 notas) — `study-pack-software-devops.zip`
- [[MOC-software-seguranca]] — Software — Segurança (200 notas) — `study-pack-software-seguranca.zip`
- [[MOC-software-testes]] — Software — Testes (200 notas) — `study-pack-software-testes.zip`
- [[MOC-software-produto]] — Software — Produto (200 notas) — `study-pack-software-produto.zip`
- [[MOC-software-jogos]] — Software — Jogos (Engenharia) (200 notas) — `study-pack-software-jogos.zip`
- [[MOC-software-sistemas-empresariais]] — Software — Sistemas Empresariais (200 notas) — `study-pack-software-sistemas-empresariais.zip`
- [[MOC-software-low-code]] — Software — Low-Code (200 notas) — `study-pack-software-low-code.zip`
- [[MOC-software-automacao]] — Software — Automação (200 notas) — `study-pack-software-automacao.zip`
- [[MOC-software-apis]] — Software — APIs (200 notas) — `study-pack-software-apis.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-software.canvas`
