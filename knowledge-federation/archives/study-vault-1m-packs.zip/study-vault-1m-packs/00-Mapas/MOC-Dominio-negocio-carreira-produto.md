---
tipo: moc-dominio
dominio: negocio-carreira-produto
tags: [moc, moc-dominio, ledger-1m]
aliases: ["Negócio, Carreira e Produto"]
---
# Negócio, Carreira e Produto — Mapa de Subdomínios

Domínio: `negocio-carreira-produto`
Subdomínios / Study Packs: **8**
Notas curadas neste domínio: **1600**

## Study Packs do Domínio

- [[MOC-negocio-mvp]] — Negócio — MVP (200 notas) — `study-pack-negocio-mvp.zip`
- [[MOC-negocio-validacao]] — Negócio — Validação (200 notas) — `study-pack-negocio-validacao.zip`
- [[MOC-negocio-monetizacao]] — Negócio — Monetização (200 notas) — `study-pack-negocio-monetizacao.zip`
- [[MOC-negocio-portfolio]] — Negócio — Portfólio (200 notas) — `study-pack-negocio-portfolio.zip`
- [[MOC-negocio-carreira]] — Negócio — Carreira (200 notas) — `study-pack-negocio-carreira.zip`
- [[MOC-negocio-mercado]] — Negócio — Mercado (200 notas) — `study-pack-negocio-mercado.zip`
- [[MOC-negocio-distribuicao]] — Negócio — Distribuição (200 notas) — `study-pack-negocio-distribuicao.zip`
- [[MOC-negocio-produto]] — Negócio — Produto (200 notas) — `study-pack-negocio-produto.zip`

## Navegação

- Voltar para [[Home]]
- Abrir Canvas do domínio: `_canvas/Mapa-negocio-carreira-produto.canvas`
