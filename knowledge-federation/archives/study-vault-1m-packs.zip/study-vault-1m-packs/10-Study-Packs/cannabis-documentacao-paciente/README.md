# Recorte materializado do checkpoint

Pacote: `cannabis-documentacao-paciente`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=paciente-documentacao
