---
tipo: moc
dominio: home
tags: [home, study-pack, ledger-1m]
aliases: [Home, Study Vault 1M]
---
# Home — Study Vault Completo (78 Subdomínios / 15.600 Notas)

Este vault contém os **78 study packs temáticos** (100% dos subdomínios da taxonomia, com **200 notas por subdomínio = 15.600 notas curadas**), derivados do ledger de **1.000.000 de notas lógicas**.

Gerado em: 2026-10-01T20:21:16

## Mapas por Domínio (7 Domínios / 78 Subdomínios)

- [[MOC-Dominio-software|Engenharia de Software]] — 16 packs (3200 notas)
- [[MOC-Dominio-ia|Inteligência Artificial]] — 12 packs (2400 notas)
- [[MOC-Dominio-vibe-coding|Vibe Coding e Orquestração Agêntica]] — 10 packs (2000 notas)
- [[MOC-Dominio-jogos|Desenvolvimento de Jogos]] — 12 packs (2400 notas)
- [[MOC-Dominio-cannabis-medicinal|Cannabis Medicinal (Educacional e Regulatório)]] — 11 packs (2200 notas)
- [[MOC-Dominio-micologia|Micologia Segura e Científica]] — 9 packs (1800 notas)
- [[MOC-Dominio-negocio-carreira-produto|Negócio, Carreira e Produto]] — 8 packs (1600 notas)

## Trilhas guiadas

- [[Trilha-Orquestrador-de-IA]]
- [[Trilha-Fullstack-com-IA]]
- [[Trilha-Jogos-2D-Online-MMO]]
- [[Trilha-Produto-Carreira-MVP]]
- [[Trilha-Ciencias-Reguladas-Seguras]]

## Playbooks e matrizes de decisão

- [[Como-Estudar-Um-Pack|Playbook — Como estudar um pack]]
- [[Como-Materializar-Novos-Recortes|Playbook — Como materializar novos recortes]]
- [[Checklist-Fontes-e-Volatilidade|Checklist — Fontes e Volatilidade]]
- [[Matriz-Ferramentas-IA-Dev|Matriz — Ferramentas de IA para Desenvolvimento]]
- [[Matriz-Engine-Jogos|Matriz — Engine para Jogos]]
- [[Perguntas-Para-Profissionais-Regulados|Perguntas para profissionais em domínios regulados]]

## Todos os 78 Study Packs por Subdomínio

- [[MOC-software-fundamentos]] — Software — Fundamentos (200 notas)
- [[MOC-software-arquitetura]] — Software — Arquitetura (200 notas)
- [[MOC-software-frontend]] — Software — Frontend (200 notas)
- [[MOC-software-backend]] — Software — Backend (200 notas)
- [[MOC-software-mobile]] — Software — Mobile (200 notas)
- [[MOC-software-desktop]] — Software — Desktop (200 notas)
- [[MOC-software-dados]] — Software — Dados (200 notas)
- [[MOC-software-devops]] — Software — DevOps (200 notas)
- [[MOC-software-seguranca]] — Software — Segurança (200 notas)
- [[MOC-software-testes]] — Software — Testes (200 notas)
- [[MOC-software-produto]] — Software — Produto (200 notas)
- [[MOC-software-jogos]] — Software — Jogos (Engenharia) (200 notas)
- [[MOC-software-sistemas-empresariais]] — Software — Sistemas Empresariais (200 notas)
- [[MOC-software-low-code]] — Software — Low-Code (200 notas)
- [[MOC-software-automacao]] — Software — Automação (200 notas)
- [[MOC-software-apis]] — Software — APIs (200 notas)
- [[MOC-ia-fundamentos]] — IA — Fundamentos (200 notas)
- [[MOC-ia-llms]] — IA — LLMs (200 notas)
- [[MOC-ia-agentes]] — IA — Agentes (200 notas)
- [[MOC-ia-rag]] — IA — RAG (200 notas)
- [[MOC-ia-fine-tuning]] — IA — Fine-Tuning (200 notas)
- [[MOC-ia-modelos-locais]] — IA — Modelos Locais (200 notas)
- [[MOC-ia-avaliacao]] — IA — Avaliação (200 notas)
- [[MOC-ia-seguranca]] — IA — Segurança (200 notas)
- [[MOC-ia-custos]] — IA — Custos (200 notas)
- [[MOC-ia-ferramentas]] — IA — Ferramentas (200 notas)
- [[MOC-ia-multimodal]] — IA — Multimodal (200 notas)
- [[MOC-ia-mlops]] — IA — MLOps (200 notas)
- [[MOC-vibe-coding-conceitos]] — Vibe Coding — Conceitos (200 notas)
- [[MOC-vibe-coding-ferramentas]] — Vibe Coding — Ferramentas (200 notas)
- [[MOC-vibe-coding-workflows]] — Vibe Coding — Workflows (200 notas)
- [[MOC-vibe-coding-prompts]] — Vibe Coding — Prompts (200 notas)
- [[MOC-vibe-coding-context-engineering]] — Vibe Coding — Context Engineering (200 notas)
- [[MOC-vibe-coding-spec-driven-dev]] — Vibe Coding — Spec-Driven Dev (200 notas)
- [[MOC-vibe-coding-qualidade]] — Vibe Coding — Qualidade (200 notas)
- [[MOC-vibe-coding-riscos]] — Vibe Coding — Riscos (200 notas)
- [[MOC-vibe-coding-estudos]] — Vibe Coding — Estudos (200 notas)
- [[MOC-vibe-coding-orquestracao]] — Vibe Coding — Orquestração (200 notas)
- [[MOC-jogos-2d]] — Jogos — 2D (200 notas)
- [[MOC-jogos-3d]] — Jogos — 3D (200 notas)
- [[MOC-jogos-engines]] — Jogos — Engines (200 notas)
- [[MOC-jogos-netcode]] — Jogos — Netcode (200 notas)
- [[MOC-jogos-mmo]] — Jogos — MMO (200 notas)
- [[MOC-jogos-game-design]] — Jogos — Game Design (200 notas)
- [[MOC-jogos-level-design]] — Jogos — Level Design (200 notas)
- [[MOC-jogos-arte]] — Jogos — Arte (200 notas)
- [[MOC-jogos-audio]] — Jogos — Áudio (200 notas)
- [[MOC-jogos-ui-ux]] — Jogos — UI/UX (200 notas)
- [[MOC-jogos-publicacao]] — Jogos — Publicação (200 notas)
- [[MOC-jogos-live-ops]] — Jogos — Live Ops (200 notas)
- [[MOC-cannabis-legal-regulatorio]] — Cannabis Medicinal — Legal e Regulatório (200 notas)
- [[MOC-cannabis-documentacao-paciente]] — Cannabis Medicinal — Documentação do Paciente (200 notas)
- [[MOC-cannabis-botanica-geral]] — Cannabis Medicinal — Botânica Geral (200 notas)
- [[MOC-cannabis-farmacologia]] — Cannabis Medicinal — Farmacologia (200 notas)
- [[MOC-cannabis-canabinoides]] — Cannabis Medicinal — Canabinoides (200 notas)
- [[MOC-cannabis-terpenos]] — Cannabis Medicinal — Terpenos (200 notas)
- [[MOC-cannabis-formas-de-uso-legais]] — Cannabis Medicinal — Formas de Uso Legais (200 notas)
- [[MOC-cannabis-riscos-interacoes]] — Cannabis Medicinal — Riscos e Interações (200 notas)
- [[MOC-cannabis-estudos-clinicos]] — Cannabis Medicinal — Estudos Clínicos (200 notas)
- [[MOC-cannabis-qualidade-rastreabilidade]] — Cannabis Medicinal — Qualidade e Rastreabilidade (200 notas)
- [[MOC-cannabis-glossario]] — Cannabis Medicinal — Glossário (200 notas)
- [[MOC-micologia-fundamentos]] — Micologia — Fundamentos (200 notas)
- [[MOC-micologia-taxonomia]] — Micologia — Taxonomia (200 notas)
- [[MOC-micologia-ecologia]] — Micologia — Ecologia (200 notas)
- [[MOC-micologia-cogumelos-comestiveis-legais]] — Micologia — Cogumelos Comestíveis Legais (200 notas)
- [[MOC-micologia-cogumelos-medicinais-legais]] — Micologia — Cogumelos Medicinais Legais (200 notas)
- [[MOC-micologia-psilocybe-historia-taxonomia-legislacao]] — Micologia — Psilocybe: História, Taxonomia e Legislação (200 notas)
- [[MOC-micologia-psilocibina-pesquisa-clinica]] — Micologia — Psilocibina: Pesquisa Clínica (200 notas)
- [[MOC-micologia-riscos-reducao-danos]] — Micologia — Riscos e Redução de Danos (200 notas)
- [[MOC-micologia-glossario]] — Micologia — Glossário (200 notas)
- [[MOC-negocio-mvp]] — Negócio — MVP (200 notas)
- [[MOC-negocio-validacao]] — Negócio — Validação (200 notas)
- [[MOC-negocio-monetizacao]] — Negócio — Monetização (200 notas)
- [[MOC-negocio-portfolio]] — Negócio — Portfólio (200 notas)
- [[MOC-negocio-carreira]] — Negócio — Carreira (200 notas)
- [[MOC-negocio-mercado]] — Negócio — Mercado (200 notas)
- [[MOC-negocio-distribuicao]] — Negócio — Distribuição (200 notas)
- [[MOC-negocio-produto]] — Negócio — Produto (200 notas)

Total materializado neste vault: **15600 notas** em **78 study packs**.

## Mapas visuais (Obsidian Canvas)

- `_canvas/Mapa-Geral.canvas` (visão geral dos 7 domínios e 78 packs)
- `_canvas/Trilhas-e-Playbooks.canvas` (trilhas guiadas e matrizes de decisão)
- `_canvas/Mapa-software.canvas`
- `_canvas/Mapa-ia.canvas`
- `_canvas/Mapa-vibe-coding.canvas`
- `_canvas/Mapa-jogos.canvas`
- `_canvas/Mapa-cannabis-medicinal.canvas`
- `_canvas/Mapa-micologia.canvas`
- `_canvas/Mapa-negocio-carreira-produto.canvas`
