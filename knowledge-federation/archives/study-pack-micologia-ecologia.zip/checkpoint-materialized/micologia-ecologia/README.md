# Recorte materializado do checkpoint

Pacote: `micologia-ecologia`
Notas: 200
Filtro: domain=micologia, subdomain=ecologia
