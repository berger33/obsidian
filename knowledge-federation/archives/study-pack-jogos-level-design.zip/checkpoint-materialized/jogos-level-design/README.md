# Recorte materializado do checkpoint

Pacote: `jogos-level-design`
Notas: 200
Filtro: domain=jogos, subdomain=level-design
