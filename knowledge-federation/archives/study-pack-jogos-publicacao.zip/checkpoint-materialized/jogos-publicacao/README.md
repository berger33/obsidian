# Recorte materializado do checkpoint

Pacote: `jogos-publicacao`
Notas: 200
Filtro: domain=jogos, subdomain=publicacao
