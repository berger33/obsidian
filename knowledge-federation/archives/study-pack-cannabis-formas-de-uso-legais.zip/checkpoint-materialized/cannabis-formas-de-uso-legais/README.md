# Recorte materializado do checkpoint

Pacote: `cannabis-formas-de-uso-legais`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=formas-de-uso-legais
