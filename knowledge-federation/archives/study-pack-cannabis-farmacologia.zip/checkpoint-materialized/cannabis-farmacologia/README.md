# Recorte materializado do checkpoint

Pacote: `cannabis-farmacologia`
Notas: 200
Filtro: domain=cannabis-medicinal, subdomain=farmacologia
